﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Library_1;

namespace Library_3
{
    public class KI3_Class_3 : KI3_Class_1
    {
        public double F3(double x, double y)
        {
            return 3 * F1(x, y);
        }
    }
}
